from tensorflow_tts.losses.spectrogram import TFMelSpectrogram
from tensorflow_tts.losses.stft import TFMultiResolutionSTFT
